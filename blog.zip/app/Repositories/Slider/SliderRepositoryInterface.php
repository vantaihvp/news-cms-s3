<?php
namespace App\Repositories\Slider;

interface SliderRepositoryInterface
{
    
    // public function get();
}