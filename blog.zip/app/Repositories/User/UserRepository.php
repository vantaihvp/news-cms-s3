<?php
namespace App\Repositories\User;

use App\Repositories\EloquentRepository;
use Hash;
class UserRepository extends EloquentRepository implements UserRepositoryInterface
{

    /**
     * get model
     * @return string
     */
    public function getModel()
    {
        return \App\Models\User::class;
    }

    public function create(array $attributes){
        $attributes['password'] = Hash::make($attributes['password']);
        $user = $this->_model->create($attributes);
        $user->assignRole($attributes['roles']);
        return $user;
    }
    public function getAllPaginate($per_page){
        $users = $this->_model->orderBy('id','DESC')->paginate($per_page);
        foreach ($users as $key => $value) {
            $users[$key]['role'] = $value->getRoleNames();
        }
        return $users;
    }
    
}