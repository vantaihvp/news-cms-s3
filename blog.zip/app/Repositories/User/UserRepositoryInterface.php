<?php
namespace App\Repositories\User;

interface UserRepositoryInterface
{
    
}