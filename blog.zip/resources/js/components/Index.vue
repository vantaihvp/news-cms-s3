<template>
    <div id="main">
        <div id="content">
            <router-view></router-view>
        </div>
    </div>
</template>
<script>
export default {
    data() {
        return {
            //
        };
    },
    components: {
        //
    },
    mounted() {}
};
</script>
