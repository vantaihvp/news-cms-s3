<template>
    <section class="users">
        <router-view></router-view>
    </section>
</template>

<script>
export default {};
</script>

<style></style>
