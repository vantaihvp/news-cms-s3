<template>
  <div class="user-create">
    <div class="row mb-4">
      <div class="col-lg-12 margin-tb">
        <div class="float-left">
          <h2>Chỉnh sửa vai trò</h2>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-12">
        <div class="card shadow-none border-0">
          <div class="card-body" id="user-create">
            <div class="error" v-if="errors.length">
              <div class="alert alert-danger" role="alert">
                <span v-for="(err, index) in errors" :key="index">{{ err }}</span>
                <hr />
              </div>
            </div>
            <form action method="POST" @submit.prevent="submitEditRole">
              <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                  <div class="form-group">
                    <label class="lable-required">Tên:</label>
                    <input type="text" v-model="name" name="name" class="form-control" required />
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label class="lable-required">Permissions:</label>
                    <table class="table table-striped table-bordered permissions_table">
                      <tr>
                        <td>
                          <h6 class="mb-2 font-weight-bold">
                            <label>1</label>
                          </h6>
                          <div class="icheck-success">
                            <label
                              class="mr-4"
                              v-for="permission in permissions"
                              :key="permission.id"
                            >
                              <input
                                type="checkbox"
                                v-bind:name="permission.name"
                                :checked="hasPermission(rolePermissions,permission.name)== true"
                              />
                              {{permission.name}}
                            </label>
                          </div>
                        </td>
                      </tr>
                    </table>
                  </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 text-right">
                  <button type="submit" class="btn btn-primary">Cập nhật</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ["id"],
  data() {
    return {
      name: "",
      data: [],
      permissions: [],
      rolePermissions: [],
      errors: []
    };
  },
  methods: {
    getRole() {
      axios
        .get("auth/roles/" + this.id)
        .then(rs => {
          if (rs.status === 200) {
            this.data = rs.data;
            this.name = rs.data.role.name;
            this.rolePermissions = rs.data.rolePermissions;
          }
        })
        .catch(error => {
          this.errors = error;
          console.log(error);
        });
    },
    getPermissions() {
      axios
        .get("auth/permissions")
        .then(rs => {
          this.permissions = rs.data;
        })
        .catch(error => {});
    },
    submitEditRole(event) {
      let dataForm = new FormData(event.currentTarget);
      var object = {};
      dataForm.forEach((value, key) => {
        object[key] = value;
      });
      var json = JSON.stringify(object);
      console.log("submitEditRole -> json", json);
      axios
        .put("auth/roles/" + this.id, json, {
          headers: {
            "Content-Type": "application/json"
          }
        })
        .then(rs => {
          console.log(rs);
          this.$router.push({
            path: "/admin/roles",
            params: { message: "Chỉnh sửa thành công" }
          });
        })
        .catch(error => {
          console.log("--------");
          this.errors = error.response.data.errors;
          console.log(error.response.data.errors);
        });
    },
    hasPermission(permissions, rolePermission) {
      let isHas = false;
      permissions.forEach(p => {
        if (p.name === rolePermission) {
          isHas = true;
        }
      });
      return isHas;
    }
  },
  created() {
    this.getRole();
    this.getPermissions();
  }
};
</script>

<style></style>
