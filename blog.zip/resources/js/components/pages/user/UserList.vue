<template>
  <section>
    <div class="row mb-4">
      <div class="col-lg-12 margin-tb">
        <div class="float-left">
          <h2>Danh sách thành viên</h2>
        </div>
        <div class="float-right">
          <div class="button-box">
            <router-link
              :to="{ name: 'user-create' }"
              class="btn btn-primary"
              v-if="this.$can('user-create')"
            >Thêm mới</router-link>
          </div>
        </div>
      </div>
    </div>
    <div class="card border-0 shadow-none">
      <div class="card-body">
        <div class="error" v-if="error.message.length">
          <div class="alert alert-danger" role="alert">{{ error.message }}</div>
        </div>
        <div class="success" v-if="status === 'success'">
          <div class="alert alert-success" role="alert">{{ message }}</div>
        </div>
        <div>
          <table class="table table-bordered">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Họ tên</th>
                <th scope="col">Bút danh</th>
                <th scope="col">Email</th>
                <th scope="col">Phone</th>
                <th scope="col">Vai trò</th>
                <th scope="col" class="text-center">Hành động</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="(user, index) in users" :key="'user-' + index">
                <th scope="row">{{ user.id }}</th>
                <td>{{ user.name }}</td>
                <td>{{ user.pseudonym }}</td>
                <td>{{ user.email }}</td>
                <td>{{ user.phone_number }}</td>
                <td>
                  <label
                    class="badge badge-success"
                    v-for="(role,index) in user.role"
                    :key="'role-'+index"
                  >{{role}}</label>
                </td>
                <td class="text-center" width="160px">
                  <router-link
                    :to="{ name: 'user-edit',params: { id: user.id }}"
                    v-if="$can('user-edit')"
                    class="btn btn-warning"
                  >
                    <i class="far fa-pencil"></i>
                  </router-link>
                  <button
                    class="btn btn-danger"
                    @click="deleteUser(user.id)"
                    v-if="$can('user-delete')"
                  >
                    <i class="far fa-trash"></i>
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  props: {
    message: String,
    status: ""
  },
  data() {
    return {
      users: [],
      error: {
        message: ""
      }
    };
  },
  created() {
    this.getUsers();
    // console.log(this.$can("role-list"));
  },
  methods: {
    getUsers() {
      axios
        .get("auth/users")
        .then(response => {
          if (response.data.status === false) {
            this.error.message = response.data.message;
          } else {
            this.users = response.data.success.data;
          }
        })
        .catch();
    },
    deleteUser(userId) {
      var result = confirm("Are you sure you want to delete this user?");
      if (result) {
        axios
          .delete("/auth/users/" + userId)
          .then(rs => {
            this.getUsers();
          })
          .catch(error => {
            console.log(error);
          });
      }
    }
  }
};
</script>

<style></style>
