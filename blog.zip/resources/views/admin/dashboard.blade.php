@extends('layouts.admin-lte')

@section('title', 'Dashboard 1')

@section('content_header')
<h1>Dashboard</h1>
@stop

@section('app')
<app></app>
<script type="application/javascript">
</script>
@stop