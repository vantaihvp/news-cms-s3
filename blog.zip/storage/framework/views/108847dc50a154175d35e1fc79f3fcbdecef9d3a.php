
<?php $__env->startSection('content'); ?>
<h1>This is a vue component</h1>
 <div id="app">
  <router-view></router-view>
 </div>
 <script src="<?php echo e(asset('js/all-custom.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\billboard\blog\resources\views/vue/index.blade.php ENDPATH**/ ?>