<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
<h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('app'); ?>
<index></index>
<script type="application/javascript">
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-lte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\billboard\blog\resources\views/welcome.blade.php ENDPATH**/ ?>