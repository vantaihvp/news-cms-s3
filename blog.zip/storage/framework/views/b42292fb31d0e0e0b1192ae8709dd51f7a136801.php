

<?php $__env->startSection('title', 'Dashboard 1'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('app'); ?>
    <app></app>
<script type="application/javascript">
    <?php if(auth()->guard()->check()): ?>
        window.Permissions = <?php echo json_encode(Auth::user()->allPermissions, true); ?>;
        window.__user__ = <?php echo json_encode(Auth::user(), true, 512) ?>;
    <?php else: ?>
        window.Permissions = [];
    <?php endif; ?>
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin-lte', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\billboard\blog\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>